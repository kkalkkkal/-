package com.example.naverocr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new Thread(){
            public void run() {
                StringBuffer response = new StringBuffer();
                response = OCRGeneralAPIDemo();

                System.out.println(response);
            }
        }.start();

    }

    public StringBuffer OCRGeneralAPIDemo() {

        // API invoke URL
        String apiURL = "https://cf667635821d4e27a149417a936140aa.apigw.ntruss.com/custom/v1/8069/4ee8c59db77aec20ccac405e431d4e27f0345fe1b12edb62281840e6670452cc/general";

        // API secretKey
        String secretKey = "Sk16UE5tUFltdlpyVmlCc1hGYlRaaWpUbHNrZWR5cHg=";

        try {
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setUseCaches(false);
            con.setDoInput(true);
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setRequestProperty("X-OCR-SECRET", secretKey);

            JSONObject json = new JSONObject();
            json.put("version", "V2");
            json.put("requestId", UUID.randomUUID().toString());
            json.put("timestamp", System.currentTimeMillis());
            JSONObject image = new JSONObject();
            image.put("format", "jpg");
            //image.put("url", "https://kr.object.ncloudstorage.com/ocr-ci-test/sample/1.jpg"); // image should be public, otherwise, should use data


            InputStream inputStream1 = getResources().openRawResource(R.raw.milk);

            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            Resources res= getResources();

            Bitmap bitmap = BitmapFactory.decodeResource(res, R.raw.milk);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outStream);

            byte[] image2 = outStream.toByteArray();
            String profileImageBase64 = Base64.encodeToString(image2, 0);

            File tempFile = File.createTempFile(String.valueOf(inputStream1.hashCode()), ".jpg");

            copyInputStreamToFile(inputStream1, tempFile);
            System.out.println(tempFile.getAbsolutePath());

            FileInputStream inputStream = new FileInputStream(tempFile.getAbsolutePath());
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();
            image.put("data", profileImageBase64); // buffer
            image.put("name", "demo");
            JSONArray images = new JSONArray();
            images.put(image);
            json.put("images", images);
            String postParams = json.toString();

            tempFile.deleteOnExit();

            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(postParams);
            wr.flush();
            wr.close();

            int responseCode = con.getResponseCode();
            BufferedReader br;
            if (responseCode == 200) {
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();

            System.out.println(response);

            return response;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    public static void copyInputStreamToFile(InputStream inputStream, File file) {

        try (FileOutputStream outputStream = new FileOutputStream(file)) {
            int read;
            byte[] bytes = new byte[1024];

            while ((read = inputStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, read);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}