package com.example.a2fg_ver1;

import androidx.activity.result.ActivityResultCaller;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;


import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;

import java.util.ArrayList;


//GestureDetector.OnDoubleTapLister: 두 번 터치와 관련된 리스너
//GestureDetector.OnGestureListener: 다양한 화면 터치 이벤트를 처리하는 리스너
public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener,
        RecognitionListener, TextToSpeech.OnInitListener, ActivityResultCaller {

    private static final int PERMISSION = 1;
    private SpeechRecognizer speech;
    private Intent recognizerIntent;
    private TextView textView;
    private final int RESULT_SPEECH = 1000;

    private GestureDetector detector;
    private static final String TAG = "Gesture";    //로그에서 제스처 확인용

    private int scount = 0;  //scroll 동작 수
    private int twofingercheck = 0;   //두 손가락인지 확인
    double prevX = -1, prevY = -1;  //처음 화면 터치 시 위치
    double afterX = -1, afterY = -1;// 화면에서 touch up 했을 때 위치

    public void executeSTT() {
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ko-KR"); //언어지정입니다.
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);   //검색을 말한 결과를 보여주는 갯수
        startActivityForResult(recognizerIntent, RESULT_SPEECH);
        scount = 0;
        twofingercheck = 0;
        prevX = -1;
        prevY = -1;
        afterY = -1;
        afterX = -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int pointerCount = event.getPointerCount();
        this.detector.onTouchEvent(event);

        if (pointerCount == 2) {//두 손가락으로 터치 시
            Log.i(TAG, "twofinger" + event.toString());
            twofingercheck++;
        }

        switch (event.getAction()){

            case MotionEvent.ACTION_POINTER_UP:
                afterX = event.getX();
                afterY = event.getY();

                //손가락을 화면에서 떼면
                //위로 스크롤 할 때 필요한 motion event
                //ACTION_POINTER_DOWN 1회
                //OnScrollMotionEvent n회
                //ACTION_POINTER_UP 1회
                //확인
                Log.i(TAG, "/s:" + scount + "/tfc:" + twofingercheck + "/prX:" + prevX + "/prY:" + prevY + "/afX:" + afterX + "/afY:" + afterY);

                if (twofingercheck >= 1 && prevY > afterY &&  scount >= 1) {
                    // 두 손가락 터치이고 화면을 올리는 동작인 경우
                    //asr 실행
                    Log.i(TAG, "/s:" + scount + "/tfc:" + twofingercheck + "/prX:" + prevX + "/prY:" + prevY + "/afX:" + afterX + "/afY:" + afterY);
                    executeSTT();
                    Log.i(TAG, "STT");
                    Log.i(TAG, "/s:" + scount + "/tfc:" + twofingercheck + "/prX:" + prevX + "/prY:" + prevY + "/afX:" + afterX + "/afY:" + afterY);

                }
                break;
            default:
                break;
        }

        return super.onTouchEvent(event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        detector = new GestureDetector(this, this);

        if (Build.VERSION.SDK_INT >= 23) {
            // 퍼미션 체크
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET,
                    Manifest.permission.RECORD_AUDIO}, PERMISSION);
        }


        //sst
        speech = SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(this);
        textView = findViewById(R.id.sttResult);

    }


    //MotionEvent Overriding 함수


    @Override
    public boolean onDown(MotionEvent e) {
        if(twofingercheck==0){
            prevX = e.getX();
            prevY = e.getY();
        }
        Log.i(TAG, "onDown" + e.toString());
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        if (twofingercheck >= 1) scount++;

        Log.i(TAG, "onScroll" + e1.toString() + "," + e2.toString());
        return false;
    }


    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {
    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        Log.i(TAG, "onSingleTapUp" + e.toString());
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {
    }


    //stt override 함수들
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case RESULT_SPEECH: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> text = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    for (int i = 0; i < text.size(); i++) {
                        textView.setText(text.get(i));
                    }
                    for (int i = 0; i < text.size(); i++) {
                        Log.e("MainActivity", "onActivityResult text : " + text.get(i));
                    }
                }

                break;
            }
        }
    }

    @Override
    public void onError(int error) {
        String message;

        switch (error) {

            case SpeechRecognizer.ERROR_AUDIO:
                message = "오디오 에러";
                break;

            case SpeechRecognizer.ERROR_CLIENT:
                message = "클라이언트 에러";
                break;

            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "퍼미션없음";
                break;

            case SpeechRecognizer.ERROR_NETWORK:
                message = "네트워크 에러";
                break;

            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "네트웍 타임아웃";
                break;

            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "찾을수 없음";
                ;
                break;

            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "바쁘대";
                break;

            case SpeechRecognizer.ERROR_SERVER:
                message = "서버이상";
                ;
                break;

            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "말하는 시간초과";
                break;

            default:
                message = "알수없는 에러";
                break;
        }
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
    }

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onRmsChanged(float rmsdB) {
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
    }

    @Override
    public void onEndOfSpeech() {
    }

    @Override
    public void onResults(Bundle results) {
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
    }

    @Override
    public void onInit(int status) {
    }
}